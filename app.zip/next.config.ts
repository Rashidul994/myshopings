import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  experimental: {
    appdir: true
  },


   images: {
    domains: ['localhost'], // লোকালহোস্টে হোস্ট করা ছবি লোড করার জন্য
  },
  
};

export default nextConfig;
