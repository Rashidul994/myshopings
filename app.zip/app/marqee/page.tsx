// components/Marquee.js
const marqueeItems = [
  "🔥 Hot Sale: Up to 70% Off!",
  "🚚 Free Shipping Worldwide",
  "💎 Premium Quality Products",
  "⚡ Limited-Time Offer",
  "🎁 Buy 1 Get 1 Free ",
];

export default function Marquee({brand,brandname}) {
  return (
    <div className="relative overflow-hidden bg-black text-white py-3">
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-black via-transparent to-black z-10 pointer-events-none"></div>
    
      <div className="animate-marquee whitespace-nowrap flex items-center gap-16 px-4 text-lg font-medium tracking-wide">
          {brand}
        {marqueeItems.map((item, i) => (
          <span key={i} className="glow-text">
            {item}
          </span>
        ))}
        {/* Repeat for seamless scroll */}
        {marqueeItems.map((item, i) => (
          <span key={`repeat-${i}`} className="glow-text">
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
