import LiveProductValue from './StocksOptins/Stock_Live';
import ProfileChart from './StocksOptins/StockCharts';
import ProfitBalcnse from './StocksOptins/StockBlance';
import Profile from './StocksOptins/ProfitsCharts';


export default function ProfilePage() {
  return (
    // <div className="space-y-6 px-4 py-6 max-w-4xl mx-auto">
    //   <h1 className="text-2xl font-bold">👤 Profile Overview</h1>
    //   <LiveProductValue />
    //   <ProfileChart />
    // </div>
  
 <div className="px-4 py-6 max-w-5xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">📊 Dashboard</h1>
   
   <ProfitBalcnse />    
      <ProfileChart />
      <LiveProductValue />
      <Profile />
    </div>


);
}
