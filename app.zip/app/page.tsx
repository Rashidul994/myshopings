'use client';

import { useEffect, useState } from 'react';
import ProductCard from './components/ProductCard';
import { motion } from 'framer-motion';
import axios from 'axios';
import { constants } from 'http2';
import Navbar from './components/Navbar';
import ShopBag from './components/ShopBag'
import Image from 'next/image';
import Marquee from './marqee/page';

import Api from './api/Api'
import HomepageVAlucup from './Products/HomepageVAlucup';

import Cardsprodut from './Products/Product_get_brand'

import Link from 'next/link';

import { useParams } from 'next/navigation';

import AnimatinsAddss from './animations/Animatins'


export default function Home() {





  const datass=[
  { "id": 1, "name": "tv", "brand": "LG","order":13, },
  { "id": 2, "name": "tv", "brand": "sony","order":13, },
  { "id": 3, "name": "tv", "brand": "walton","order":13, },

   { "id": 4, "name": "mobile", "brand": "oppo","order":13, },
  { "id": 5, "name": "mobile", "brand": "sympphony","order":13, },
  { "id": 6, "name": "mobile", "brand": "walton","order":13, },

    { "id": 8, "name": "freez", "brand": "LG","order":113, },
  { "id": 9, "name": "freez", "brand": "sony","order":13, },
  { "id": 10, "name": "freez", "brand": "walton","order":13, },

    { "id": 11, "name": "pc", "brand": "hp","order":113, },
  { "id": 12, "name": "pc", "brand": "gigabit","order":13, },
  { "id": 13, "name": "pc", "brand": "chaina produts","order":13, },
   { "id": 7, "name": "Rash", "email": "rashidul@example.com","order":113, }
];


  const [products, setProducts] = useState([]);

const [branNams, setBrnadnms]=useState('');

const [getBrand, setProducts_brand]=useState([]);
const [brand, setBrand] = useState('');
const [actions_new_old, setAction] = useState('new');









  useEffect(() => {


getUserBrandName();

getUser();

getUserBrandName_FinalDATA();













  }, [brand]);




  




// axios.get('/user', {
//     params: {
//       ID: 12345
//     }
//   })
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   })
//   .finally(function () {
//     // always executed
//   });

// Want to use async/await? Add the `async` keyword to your outer function/method.
const getUser= () =>{

  Api.get(`/get_all_product/${actions_new_old}`)
  .then(res =>{
    

     if(brand){
 
     }else{
 setProducts(res.data.message);

     }

console.log('====================================');
console.log(res.data.message);
console.log('====================================');
})
  .catch(err => console.log('errrrrrrorrrrrrrrrrrrrrrrrrrrrrrrr'+err));

//   try {
//     const response = axios.get('http://localhost:5000/api/data');
//  setProducts(response.data);
//  console.log('====================================');
//  console.log(response.data);
//  console.log('====================================');
//   } catch (error) {
//     console.error(error);
//      console.log('====================================erroreeee');
//   }
}



console.log('=========brand ===========================');
console.log(getBrand);
console.log('===============data=====================');




const getUserBrandName_FinalDATA= () =>{

  Api.get(`/get_all_product_brandName_final/${brand}/${actions_new_old}/${branNams}`)
  .then(res =>{
     setProducts_brand(res.data.message);
 if (branNams) {
   alert(res.data.message);
 }else{
  
 }
console.log('========== Brand  Final get  name ');
console.log(res.data.message);
console.log('====================================');
})
  .catch(err => console.log('Final Catagori is brand....... '+err));

}




const getUserBrandName= () =>{

  Api.get(`/get_all_product_brandName/${brand}/${actions_new_old}`)
  .then(res =>{
     setProducts_brand(res.data.message);
 if (brand) {
   setProducts(res.data.message);
 }else{
  
 }
console.log('========== Brand get name ');
console.log(res.data.message);
console.log('====================================');
})
  .catch(err => console.log('errrrrrrorrrrrrrrrrrrrrrrrrrrrrrrr Brand get error option................... '+err));

//   try {
//     const response = axios.get('http://localhost:5000/api/data');
//  setProducts(response.data);
//  console.log('====================================');
//  console.log(response.data);
//  console.log('====================================');
//   } catch (error) {
//     console.error(error);
//      console.log('====================================erroreeee');
//   }
}







  return (
    <>
        
 
    <Navbar />
    <ShopBag />
    <main className="p-6 bg-dark-50 min-h-screen">

<Marquee brand={brand}  />



      <h1 className="text-3xl font-bold txt-white  mb-6">{branNams}3D E-Commerce Store</h1>

<HomepageVAlucup brandname={branNams} Catagoris={brand} />


  
 
 
 

 
 
 
 { ! branNams ?
 
 <>
     <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
 
 
        {products.map(product => (
          <motion.div
            key={product.id}
          
            onClick={brand ? ()=>setBrnadnms(product.brand)  : ()=>setBrand(product.catagori)}
            whileHover={{ scale: 1.10 }}
            className="bg-pink-300  rounded-xl shadow-md  p-2"
          >
<h3>{product.id}</h3>

 {/* <img
        src={`${Api}/public/upload_product/${product.img}`}
      />  */}
 {product.img  ?


 <img src={`http://localhost:8000/uploads_product/${product.img}`}  />
      :

<img
        src={product.imglink}
     /> 
}       

{brand ?

<h3>{product.brand}</h3>
:
<h3>{product.catagori}</h3>

}
     <Link  href={`/product-view/${product.id}`}>get priduct </Link>

   
          </motion.div>
        ))}



</div>

</>
        :


        <>
        
<Cardsprodut       brand={brand} branName={branNams} old={actions_new_old} />



        </>

        }










      
    </main>


    </>
  );
}