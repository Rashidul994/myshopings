// pages/product/[id].tsx
import Image from 'next/image';
import { useRouter } from 'next/router';


export default function ProductPage() {
  const router = useRouter();
  const { id } = router.query;

  // Sample product data
  const product = {
    id,
    name: "Smart Watch Series 8",
    price: 199.99,
    rating: 4.5,
    image: "/watch.jpg", // public folder
    description:
      "Experience cutting-edge technology with the new Smart Watch Series 8. Track your fitness, stay connected, and look stylish.",
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Image */}
        <div className="w-full">
          <Image
            src={product.image}
            alt={product.name}
            width={800}
            height={800}
            className="rounded-2xl w-full object-cover shadow-md"
          />
        </div>

        {/* Info */}
        <div className="flex flex-col justify-between space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold">{product.name}</h1>
          <div className="text-xl text-green-600 font-semibold">${product.price}</div>
          <div className="text-yellow-500 text-sm">⭐ {product.rating} / 5</div>
          <p className="text-gray-600 leading-relaxed">{product.description}</p>

          <div className="mt-6">
            <button className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl shadow-lg transition">
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
