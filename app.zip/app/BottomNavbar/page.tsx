// 'use client';
// import Link from 'next/link';
// import { usePathname } from 'next/navigation';
// import { Home, ShoppingCart, User, Settings } from 'lucide-react';

// const navItems = [
//   { href: '/', label: 'Home', icon: <Home size={22} /> },
//   { href: '/shop', label: 'Shop', icon: <ShoppingCart size={22} /> },
//   { href: '/profile', label: 'Profile', icon: <User size={22} /> },
//   { href: '/settings', label: 'Settings', icon: <Settings size={22} /> },
// ];

// export default function BottomNav() {
//   const pathname = usePathname();

//   return (
//     <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-gray-900 shadow-md border-t border-gray-200 dark:border-gray-700 md:hidden">
//       <ul className="flex justify-around items-center h-14">
//         {navItems.map((item) => (
//           <li key={item.href}>
//             <Link href={item.href}>
//               <div className={`flex flex-col items-center text-sm transition-all duration-300 ${
//                 pathname === item.href
//                   ? 'text-blue-600 dark:text-blue-400'
//                   : 'text-gray-500 dark:text-gray-400 hover:text-blue-500'
//               }`}>
//                 {item.icon}
//                 <span className="text-xs">{item.label}</span>
//               </div>
//             </Link>
//           </li>
//         ))}
//       </ul>
//     </nav>
//   );
// }



// components/BottomNav.tsx
"use client";
import { motion } from "framer-motion";
import {
  Home,
  ShoppingCart,
  Heart,
  User,
  Search,
} from "lucide-react";

const navItems = [
  { icon: Home, label: "Home", href: "/" },
  { icon: Search, label: "Search", href: "/search" },
  { icon: ShoppingCart, label: "Cart", href: "/cart" },
  { icon: Heart, label: "Wishlist", href: "/wishlist" },
  { icon: User, label: "Profile", href: "/profile" },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 dark:bg-zinc-900/90 backdrop-blur-md border-t border-gray-200 dark:border-zinc-700 shadow-t md:hidden">
      <ul className="flex justify-between items-center px-4 py-2">
        {navItems.map(({ icon: Icon, label, href }, index) => (
          <motion.li
            key={label}
            whileTap={{ scale: 0.85 }}
            className="flex flex-col items-center text-sm text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition"
          >
            <a href={href} className="flex flex-col items-center justify-center gap-1">
              <Icon size={22} />
              <span className="text-xs">{label}</span>
            </a>
          </motion.li>
        ))}
      </ul>
    </nav>
  );
}
