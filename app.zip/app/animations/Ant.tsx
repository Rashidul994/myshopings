"use client";

import { useEffect, useState } from "react";

const Iimg1 = "/Icon/butterfly-4437_512.gif"; // Correct way to use public image
const Iimg2= "/Icon/butterfly-11465_512.gif"; // Correct way to use public image
const Iimg3 = "/Icon/ladybug-5068_512.gif"; // Correct way to use public image
const Iimg4 = "/Icon/wasp-12292_512.gif"; // Correct way to use public image

const getRandomPosition = () => ({
  top: `${Math.random() * 90}vh`,
  left: `${Math.random() * 90}vw`,
});

const Creature = ({ image, speed }: { image: string; speed: number }) => {
  const [pos, setPos] = useState(getRandomPosition());

  useEffect(() => {
    const interval = setInterval(() => {
      setPos(getRandomPosition());
    }, speed);
    return () => clearInterval(interval);
  }, [speed]);

  return (
    <img
      src={image}
      alt="creature"
      style={{
        position: "fixed",
        top: pos.top,
        left: pos.left,
        width: "80px",
        height: "80px",
        transition: `top ${speed / 1000}s linear, left ${speed / 1000}s linear`,
        zIndex: 9999,
        pointerEvents: "none",
      }}
    />
  );
};

export default function CreatureAnimation() {
  return (
    <>

      
      <Creature image={Iimg2} speed={5500} />
      <Creature image={Iimg2} speed={8500} />
      <Creature image={Iimg2} speed={9000} />
      <Creature image={Iimg4} speed={9000} />
      <Creature image={Iimg4} speed={8500} />
   
      <Creature image={Iimg4} speed={5500} />
      <Creature image={Iimg3} speed={4500} />
      <Creature image={Iimg3} speed={5100} />
      <Creature image={Iimg3} speed={4900} />
      <Creature image={Iimg1} speed={8300} />
      <Creature image={Iimg1} speed={4300} />
      <Creature image={Iimg1} speed={6300} />
    </>
  );
}
