'use client'
import ProfileCard from './Settins/ProfileCards';
import BalanceBox from './Settins/BlanceBox';
import ChartSection from './Settins/Chartsodior';
import SettingsPanel from './Settins/SettionsPaner';

export default function ProfilePage() {

  
const data = JSON.parse(localStorage.getItem("userData"));
const username = data.map(item => item.name);
const userimg = data.map(item => item.img);



  return (
    <main className="p-4 max-w-4xl mx-auto space-y-6">
      <ProfileCard  getname={username} img={userimg} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <BalanceBox />
        <ChartSection />
      </div>
      <SettingsPanel />
    </main>
  );
}
