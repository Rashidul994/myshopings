"use client"

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Menu, X, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Imgas from '../../public/Icon/rcoin2.png'
export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);




  const [isVerified, setVerifieds]=useState(true);
  const [usename, setUsenames]=useState("");
  const [pimg, setImg]=useState("");

  const categories = ['Electronics', 'Fashion', 'Home', 'Toys'];



useEffect(() => {



const data = JSON.parse(localStorage.getItem("userData"));
const username = data.map(item => item.name);
const userimg = data.map(item => item.img);

setUsenames(username);
setImg(userimg);


}, [])







  return (
    <motion.nav
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      className=" font-bold border-b-1 border-red-300 bg-dark text-white shadow-md border-bottom-red px-4 py-3 flex items-center justify-between sticky top-0 z-50"
    >
      {/* Logo */}
      <Link href="/" className="text-xl font-bold text-blue-600">My-shopings.com</Link>

      {/* Desktop Menu */}
      <div className="hidden md:flex items-center space-x-6">
        <Link href="/" className="text-gray-700 hover:text-blue-600 transition duration-300">Home</Link>
        <Link href="/products" className="text-gray-700 hover:text-blue-600 transition duration-300">Products</Link>
        <Link href="/cart" className="text-gray-700 hover:text-blue-600 transition duration-300">Cart</Link>

        {/* Categories */}
        <div className="relative">
          <button
            onClick={() => setCategoryOpen(!categoryOpen)}
            className="flex items-center text-gray-700 hover:text-blue-600 transition"
          >
            Categories <ChevronDown className="w-4 h-4 ml-1" />
          </button>
          <AnimatePresence>
            {categoryOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute bg-white shadow-lg mt-2 rounded-md p-2 space-y-2 z-50"
              >
                {categories.map((cat) => (
                  <Link
                    key={cat}
                    href={`/category/${cat.toLowerCase()}`}
                    className="block px-4 py-1 hover:bg-blue-100 rounded text-sm"
                  >
                    {cat}
                  </Link>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Search */}
        <input
          type="text"
          placeholder="Search..."
          className="px-3 py-1 border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
        />
      </div>

      {/* Profile & Menu */}
      <div className="flex items-center space-x-3 relative">
        {/* Profile Image */}
        <button onClick={() => setProfileOpen(!profileOpen)}>


          {usename ?







   <div className="flex items-center space-x-2">


    <span className="text-sm font-medium">{usename}</span>
  <div className="relative w-10 h-10">
    <Image
      src={`http://localhost:8000/profile_users/${pimg}`}
      alt={usename}
      fill
      className="rounded-full object-cover border border-gray-300"
    />
    {isVerified && (
      <div className="absolute bottom-0 right-0 bg-white rounded-full p-[2px]">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="w-3 h-3 text-blue-500"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M22 12l-2-1.732V7l-2-1.732L16 5l-2-1.732L12 2 10 3.268 8 5 6 5.268 4 7v3.268L2 12l2 1.732V17l2 1.732L8 19l2 1.732L12 22l2-1.268 2-1.732 2-.268 2-1.732v-3.268L22 12zM10 16l-4-4 1.41-1.41L10 13.17l6.59-6.59L18 8l-8 8z" />
        </svg>
      </div>
    )}
  </div>
  





  
</div>


          
//   <Image
//   src={`http://localhost:8000/profile_users/${userimg}`}
//  width={36}
//  height={36}
//   alt={username}
//   className="rounded-full border border-gray-300 object-cover"
// />
        :
        <Image
            src={pimg}
            width={36}
            height={36}
            alt={usename}
            className="rounded-full border border-gray-300"
          />

        }
          
        </button>

        {/* Profile Dropdown */}
        <AnimatePresence>
          {profileOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-14 right-0 bg-white text-black  shadow-lg-green rounded-md p-3 w-40 z-50"
            >
              <Link href="/profile" className="block px-3 py-2 hover:bg-gray-100 rounded text-sm">My Profile</Link>
              <button className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-sm text-red-600">
                Logout
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Menu Toggle */}
        <button onClick={() => setOpen(!open)} className="md:hidden">
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white shadow-lg flex flex-col items-center py-4 space-y-4">
          <Link href="/" onClick={() => setOpen(false)}>Home</Link>
          <Link href="/products" onClick={() => setOpen(false)}>Products</Link>
          <Link href="/cart" onClick={() => setOpen(false)}>Cart</Link>

          {/* Categories in Mobile */}
          <div>
            <p className="text-gray-700 font-semibold">Categories</p>
            <div className="space-y-1">
              {categories.map((cat) => (
                <Link
                  key={cat}
                  href={`/category/${cat.toLowerCase()}`}
                  onClick={() => setOpen(false)}
                  className="block text-sm text-gray-600 hover:text-blue-600"
                >
                  {cat}
                </Link>
              ))}
            </div>
          </div>

          {/* Search */}
          <input
            type="text"
            placeholder="Search..."
            className="px-3 py-1 border rounded-full text-sm w-3/4 focus:outline-none focus:ring-2 focus:ring-blue-300"
          />
        </div>
      )}
    </motion.nav>
  );
}
