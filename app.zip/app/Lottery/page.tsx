 'use client'
// import { useState } from "react";

// export default function Home() {
//   const prizes = ["৳500", "৳1000", "৳2000", "৳5000", "Better luck next time!"];
//   const [lotteryId, setLotteryId] = useState("");
//   const [currentPrize, setCurrentPrize] = useState("");
//   const [isSpinning, setIsSpinning] = useState(false);

//   const generateLottery = () => {
//     setIsSpinning(true);
//     setLotteryId("");
//     setCurrentPrize("");

//     const randomId = "LOT-" + Math.floor(Math.random() * 1000000).toString().padStart(6, "0");
//     let counter = 0;
//     const spinInterval = setInterval(() => {
//       const random = prizes[Math.floor(Math.random() * prizes.length)];
//       setCurrentPrize(random);
//       counter++;
//       if (counter > 15) {
//         clearInterval(spinInterval);
//         setIsSpinning(false);
//         setLotteryId(randomId);
//       }
//     }, 100);
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-yellow-200 to-red-200 flex items-center justify-center p-4">
//       <div className="bg-white p-8 rounded-2xl shadow-xl text-center w-full max-w-md">
//         <h1 className="text-3xl font-bold text-gray-800 mb-4">🎲 Lottery Spinner 🎲</h1>

//         <button
//           onClick={generateLottery}
//           disabled={isSpinning}
//           className={`${
//             isSpinning ? "bg-gray-400" : "bg-red-500 hover:bg-red-600"
//           } text-white px-6 py-3 rounded-full font-semibold transition duration-300`}
//         >
//           {isSpinning ? "Spinning..." : "Spin Now"}
//         </button>

//         <div className="mt-6 text-2xl font-bold text-green-600 h-10">
//           {currentPrize}
//         </div>

//         {lotteryId && (
//           <p className="mt-4 text-sm text-gray-600">🆔 Your Lottery ID: {lotteryId}</p>
//         )}
//       </div>
//     </div>
//   );
// }


// import { useState, useRef } from "react";

// export default function Home() {
//   const [prizes, setPrizes] = useState(["৳500", "৳1000", "৳2000"]);
//   const [inputPrize, setInputPrize] = useState("");
//   const [result, setResult] = useState("");
//   const [lotteryId, setLotteryId] = useState("");
//   const wheelRef = useRef(null);

//   const addPrize = () => {
//     if (inputPrize.trim() !== "") {
//       setPrizes([...prizes, inputPrize]);
//       setInputPrize("");
//     }
//   };

//   const spinWheel = () => {
//     const totalSegments = prizes.length;
//     const randomIndex = Math.floor(Math.random() * totalSegments);
//     const degreesPerSegment = 360 / totalSegments;
//     const rotation = 360 * 5 + (360 - randomIndex * degreesPerSegment - degreesPerSegment / 2);
    
//     wheelRef.current.style.transition = "transform 4s ease-out";
//     wheelRef.current.style.transform = `rotate(${rotation}deg)`;

//     const newId = "LOT-" + Math.floor(Math.random() * 1000000).toString().padStart(6, "0");

//     setTimeout(() => {
//       setResult(prizes[randomIndex]);
//       setLotteryId(newId);
//     }, 1000);
//   };

//   return (
//     <div className="min-h-screen bg-dark from-yellow-100 to-red-100 flex flex-col items-center justify-center p-4">
//       <h1 className="text-3xl font-bold mb-4 text-center">🎡 Lottery Wheel Spinner 🎡</h1>

//       <div className="flex gap-2 mb-4">
//         <input
//           type="text"
//           placeholder="Enter prize (e.g. ৳3000)"
//           className="px-3 py-2 rounded border border-gray-400"
//           value={inputPrize}
//           onChange={(e) => setInputPrize(e.target.value)}
//         />
//         <button
//           onClick={addPrize}
//           className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
//         >
//           Add Prize
//         </button>
//       </div>

//       <div className="relative w-60 h-60 rounded-full border-[10px] border-pink-500 overflow-hidden flex items-center justify-center">
//         <div ref={wheelRef} className="absolute w-full h-full rounded-full">
//           {prizes.map((prize, i) => {
//             const rotate = (360 / prizes.length) * i;
//             return (
//               <div
//                 key={i}
//                 className="absolute left-1/2 top-1/2 origin-left text-sm"
//                 style={{
//                   transform: `rotate(${rotate}deg) translateX(50%)`,
//                   transformOrigin: "0% 0%",
//                 }}
//               >
//                 {prize}
//               </div>
//             );
//           })}
//         </div>
//         <div className="absolute w-2 h-10 bg-black top-0 left-1/2 -translate-x-1/2"></div>
//       </div>

//       <button
//         onClick={spinWheel}
//         className="mt-6 bg-red-500 text-white px-6 py-3 rounded-full font-semibold hover:bg-red-600 transition"
//       >
//         Spin the Wheel
//       </button>

//       {result && (
//         <div className="mt-6 text-center">
//           <p className="text-xl text-green-600 font-bold">🎉 Prize: {result}</p>
//           <p className="text-gray-600">🎫 Lottery ID: {lotteryId}</p>
//         </div>
//       )}
//     </div>
//   );
// }






import { useState } from "react";
import WheelComponent from "react-wheel-of-prizes";

export default function Home() {
  const [prizes, setPrizes] = useState(["৳500", "৳1000", "৳2000", "৳5000", "Better luck next time"]);
  const [inputPrize, setInputPrize] = useState("");
  const [userName, setUserName] = useState("");
  const [winner, setWinner] = useState("");
  const [lotteryId, setLotteryId] = useState("");

  const addPrize = () => {
    if (inputPrize.trim() !== "") {
      setPrizes([...prizes, inputPrize]);
      setInputPrize("");
    }
  };

  const generateId = () => {
    return "LOT-" + Math.floor(Math.random() * 1000000).toString().padStart(6, "0");
  };

  const onFinished = (prize) => {
    setWinner(prize);
    setLotteryId(generateId());
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-purple-200 flex flex-col items-center justify-center px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">🎡 Lottery Wheel Spin</h1>

      {/* User Inputs */}
      <div className="w-full max-w-md bg-white p-4 rounded shadow mb-4">
        <div className="mb-2">
          <label className="block mb-1 text-sm font-semibold">Enter Your Name</label>
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            className="w-full border rounded px-3 py-2"
            placeholder="e.g. Jannat Ara"
          />
        </div>
        <div className="flex mt-2 gap-2">
          <input
            type="text"
            placeholder="Add Prize (e.g. ৳3000)"
            value={inputPrize}
            onChange={(e) => setInputPrize(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
          <button
            onClick={addPrize}
            className="bg-green-500 text-white px-4 rounded hover:bg-green-600"
          >
            ➕
          </button>
        </div>
      </div>

      {/* Wheel Component */}
      <div className="bg-white p-4 rounded shadow w-full max-w-md">
        <WheelComponent
          segments={prizes}
          segColors={["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#F7464A"]}
          onFinished={(winner) => onFinished(winner)}
          primaryColor="#000"
          contrastColor="#fff"
          buttonText="Spin Now"
          isOnlyOnce={false}
          size={200}
          upDuration={100}
          downDuration={500}
        />
      </div>

      {/* Result */}
      {winner && (
        <div className="mt-6 bg-white p-4 rounded shadow text-center w-full max-w-md">
          <h2 className="text-lg font-semibold text-green-700">🎉 Winner Details</h2>
          <p className="mt-2 text-gray-800">
            🧑‍💼 <strong>Name:</strong> {userName || "Unknown"}
          </p>
          <p className="text-gray-800">
            🎫 <strong>Lottery ID:</strong> {lotteryId}
          </p>
          <p className="text-pink-600 text-xl font-bold">
            🎁 <strong>Prize:</strong> {winner}
          </p>
        </div>
      )}
    </div>
  );
}
